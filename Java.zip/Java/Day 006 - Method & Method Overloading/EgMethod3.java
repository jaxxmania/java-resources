import java.io.*;

class Area
	{
		public double circle(double a)
			{
				return 3.1451*a*a;
			}
		
		public double rectangle(double a,double b)
			{
				return a*b;
			}
		
		public double triangle(double a,double b)
			{
				return .5*a*b;
			}
	}
	
public class EgMethod3
	{
		public static void main(String args[]) throws Exception
			{
				int choice;
				double x,y,z,temp;
				
				BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
				
				System.out.println("Input Your Choice:\n1.Circle\n2.Rectangle\n3.Triangle\n");
				choice=Integer.parseInt(bfr.readLine());
				
				Area abc=new Area();
				
				switch(choice)
					{
						case 1:
							System.out.print("Enter Radius : ");
							x=Double.parseDouble(bfr.readLine());
							temp=abc.circle(x);
							System.out.println("Area="+temp);
							break;
							
						case 2:
							System.out.print("Enter Length : ");
							x=Double.parseDouble(bfr.readLine());
							System.out.print("Enter Breadth : ");
							y=Double.parseDouble(bfr.readLine());
							temp=abc.rectangle(x,y);
							System.out.println("Area="+temp);
							break;
							
						case 3:
							System.out.print("Enter Base : ");
							x=Double.parseDouble(bfr.readLine());
							System.out.print("Enter Height : ");
							y=Double.parseDouble(bfr.readLine());
							temp=abc.triangle(x,y);
							System.out.println("Area="+temp);
							break;
							
						default:
							System.out.println("Error!!!");
					}
								
			}
	}