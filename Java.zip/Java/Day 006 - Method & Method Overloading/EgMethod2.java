import java.io.*;

class Area
	{
		public void circle(double a)
			{
				double temp=3.1415*a*a;
				System.out.println("Area of Circle="+temp);
			}
		
		public void rectangle(double a,double b)
			{
				double temp=a*b;
				System.out.println("Area of Rectangle="+temp);
			}
		
		public void triangle(double a,double b)
			{
				double temp=.5*a*b;
				System.out.println("Area of Triangle="+temp);
			}
	}
	
public class EgMethod2
	{
		public static void main(String args[]) throws Exception
			{
				int choice;
				double x,y;
				
				BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
				
				System.out.println("Input Your Choice:\n1.Circle\n2.Rectangle\n3.Triangle\n");
				choice=Integer.parseInt(bfr.readLine());
				
				Area abc=new Area();
				
				switch(choice)
					{
						case 1:
							System.out.print("Enter Radius : ");
							x=Double.parseDouble(bfr.readLine());
							abc.circle(x);
							break;
							
						case 2:
							System.out.print("Enter Length : ");
							x=Double.parseDouble(bfr.readLine());
							System.out.print("Enter Breadth : ");
							y=Double.parseDouble(bfr.readLine());
							abc.rectangle(x,y);
							break;
							
						case 3:
							System.out.print("Enter Base : ");
							x=Double.parseDouble(bfr.readLine());
							System.out.print("Enter Height : ");
							y=Double.parseDouble(bfr.readLine());
							abc.triangle(x,y);
							break;
							
						default:
							System.out.println("Error!!!");
					}
								
			}
	}