class StudentInfo
	{
		String stdName;
		int age;
		char gender;
		
		public StudentInfo(String stdName,int age)
			{
				this.stdName=stdName;
				this.age=age;
				gender='F';
			}
			
		public void display()
			{
				System.out.println("Name="+stdName+"\nAge="+age+"\nGender="+gender);
			}
	}
	
public class EgConstructorWithParameter
	{
		public static void main(String args[])
			{
				StudentInfo std=new StudentInfo("Sita",25);
				std.display();
			}
	}
