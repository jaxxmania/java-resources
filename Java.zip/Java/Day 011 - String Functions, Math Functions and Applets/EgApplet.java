import java.applet.*;
import java.awt.*;

/*
	<applet code="EgApplet.class" width="350" height="300">
	</applet>
*/

public class EgApplet extends Applet
	{
		String msg;
		
		public void init()
			{
				msg="Hello From Applet";
				setBackground(Color.green);
				setForeground(Color.red);
			}
		
		public void paint(Graphics gr)
			{
				gr.drawString(msg,30,150);
				gr.drawLine(10,20,100,200);
				gr.drawRect(15,15,150,150);
			}
	}