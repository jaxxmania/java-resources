class EgStringFunctions
{
public static void main(String args[])
{
	String s1="Welcome";
	String s2="To Java";
	String s3="welcome";
				
				System.out.println("Length of string 1 is : "+s1.length());
				System.out.println("The combined string of s1 and s2 is : "+s1.concat(s2));
				//System.out.println(s1+"\n"+s2);
				System.out.println(s1.equals(s2));
				System.out.println(s1.equalsIgnoreCase(s3));
				System.out.println("After lowercase conversion : "+s1.toLowerCase());
				System.out.println("After uppercase conversion : "+s2.toUpperCase());
				System.out.println("The 3rd character in s1 is : "+s1.charAt(3));
				System.out.println("substring of s2 is : "+s2.substring(3,6));
			}
	}