class applicant
{
	int applicantID;
	String applicantName;
	
}
class interviewer extends applicant
{
	int interviewerID;
	String interviewerName;

	public void assign()
	{
		applicantID=101;
		applicantName="Ramesh";
		interviewerID=1;
		interviewerName="Alex";
	}
	
	public void display()
	{
		System.out.println("Application ID "+applicantID);
		System.out.println("Application ID "+applicantName);
		System.out.println("Application ID "+interviewerID);
		System.out.println("Application ID "+interviewerName);
	}
}

class candidate
{
	int candidateRefID;
	String candidateName;
	
}
class employee extends applicant
{
	int employeeID;
	String employeeName;

	public void assign()
	{
		candidateRefID=1101;
		candidateName="Akash";
		employeeID=111;
		employeeName="Arbinda";
	}
	
	public void display()
	{
		System.out.println("Candidate Refferal ID "+candidateRefID);
		System.out.println("Candidate Name "+candidateName);
		System.out.println("Employee ID "+employeeID);
		System.out.println("EmployeeName "+employeeName);
	}
}