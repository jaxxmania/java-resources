import java.awt.*;

public class EgFrameMenu extends Frame
	{
		MenuBar mb;
		Menu mnu1,mnu2;
		MenuItem mi1,mi2;
	
		public EgFrameMenu()
			{
				mb=new MenuBar();
		
				mnu1=new Menu("File");
				mnu2=new Menu("Help");
				
				mi1=new MenuItem("New");
				mi2=new MenuItem("About");
				
				setMenuBar(mb);
				mb.add(mnu1);
				mb.add(mnu2);
		
				mnu1.add(mi1);
				mnu2.add(mi2);
		
				setVisible(true);
				setSize(800,600);
	
			}
	
		public static void main(String args[])
			{
				new EgFrameMenu();
			}
	}