import java.awt.*;

public class MenuExample extends Frame
{
	MenuBar mb;
	Menu mnu1,mnu2;
	MenuItem mi1,mi2;
	
	public MenuExample()
	{
		mb=new MenuBar();
		
		mnu1=new Menu("Menu1");
		mnu2=new Menu("Menu2");
		
		mi1=new MenuItem("MenuItem1");
		mi2=new MenuItem("MenuItem2");
		
		setMenuBar(mb);
		mb.add(mnu1);
		mb.add(mnu2);
		
		mnu1.add(mi1);
		mnu2.add(mi2);
		
		setVisible(true);
		setSize(1200,1024);
	
	}
	public static void main(String args[])
	{
		new MenuExample();
	}
}