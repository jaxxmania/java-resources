import java.awt.*;

public class EgFrameMenu2 extends Frame implements EventListener
	{
		MenuBar mb;
		Menu mnu1,mnu2;
		MenuItem mi1,mi2,mi3,mi4;
	
		public EgFrameMenu2()
			{
				mb=new MenuBar();
		
				mnu1=new Menu("Record Management");
				mnu2=new Menu("Help");
				
				mi1=new MenuItem("Add Record");
				mi2=new MenuItem("Edit Record");
				mi3=new MenuItem("Delete Record");
				mi4=new MenuItem("About");
				
				setMenuBar(mb);
				mb.add(mnu1);
				mb.add(mnu2);
		
				mnu1.add(mi1);
				mi1.addEventListener(this);

				mnu1.add(mi2);
				mnu1.add(mi3);
				mnu2.add(mi4);
		
				setVisible(true);
				setSize(800,600);
	
			}

		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==mi1)
					{
						
					}
			}
	
		public static void main(String args[])
			{
				new EgFrameMenu2();
			}
	}