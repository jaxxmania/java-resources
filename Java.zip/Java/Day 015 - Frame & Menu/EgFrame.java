import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EgFrame extends Frame implements ActionListener
	{
		Label lblUser,lblPass;
		TextField txtUser,txtPass;
		Button btnLogin;

		public EgFrame()
			{
				setLayout(null);

				lblUser=new Label("Username");
				lblPass=new Label("Password");

				txtUser=new TextField(30);
				txtPass=new TextField(30);
				txtPass.setEchoChar('|');

				btnLogin=new Button("Login");

				add(lblUser);
				lblUser.setBounds(20,50,100,25);

				add(txtUser);
				txtUser.setBounds(130,50,150,25);

				add(lblPass);
				lblPass.setBounds(20,80,100,25);

				add(txtPass);
				txtPass.setBounds(130,80,150,25);

				add(btnLogin);
				btnLogin.setBounds(50,110,50,25);
				btnLogin.addActionListener(this);

				setVisible(true);
				setSize(300,150);
				setTitle("Login");
				setLocation(250,250);
				setResizable(false);
			}

		public void actionPerformed(ActionEvent ae)
			{
				String strUser="Angel";
				String strPass="Angel123";

				if(ae.getSource()==btnLogin)
					{
						if(strUser.equals(txtUser.getText()) && strPass.equals(txtPass.getText()))
							//JOptionPane.showMessageDialog(null,"Login Successful","Success",JOptionPane.INFORMATION_MESSAGE);
							new EgFrameMenu();

						else
							JOptionPane.showMessageDialog(null,"Login Error !","Error!",JOptionPane.INFORMATION_MESSAGE);
					}	
			}

		public static void main(String args[])
			{
				new EgFrame();
			}
	}