class First
{
public void display()
{
System.out.println("Eg. of method");
}
}

public class EgMethod
{
public static void main(String args[])
{
First fs=new First();
fs.display();
}
}