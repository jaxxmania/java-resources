import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*
	<applet code="EgEventHandling.class" width="400" height="400">
	</applet>
*/

public class EgEventHandling extends Applet implements ActionListener
	{
		TextField messageField;
		TextArea commonArea;
		Button btnSend;
		
		public void init()
			{
				setLayout(null);
				
				commonArea=new TextArea("",10,25);
				messageField=new TextField(25);
				btnSend=new Button("Send");
				
				add(commonArea);
				commonArea.setBounds(20,20,150,150);
				
				add(messageField);
				messageField.setBounds(20,200,150,25);
				
				add(btnSend);
				btnSend.setBounds(175,200,50,25);
				
				btnSend.addActionListener(this);
			}
		
		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==btnSend)
					{
						String s1=messageField.getText();
						String s2=commonArea.getText();
						commonArea.setText(s1+"\n"+s2);
						messageField.setText("");
					}
			}
	}