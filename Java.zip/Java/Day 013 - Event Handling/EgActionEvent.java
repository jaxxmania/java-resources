import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*
<applet code="EgActionEvent.class" width="300" height="300">
</applet>
*/

public class EgActionEvent extends Applet implements ActionListener
	{
		Label lblName,lblNameDisplay;
		TextField txtName,txtNameDisplay;
		Button btnDisplay;
		
		public void init()
			{
				lblName=new Label("Name : ");
				lblNameDisplay=new Label("Your Name Is : ");
				
				txtName=new TextField(20);
				txtNameDisplay=new TextField(20);
				
				btnDisplay=new Button("Display");
				
				add(lblName);
				add(txtName);
				add(lblNameDisplay);
				add(txtNameDisplay);
				add(btnDisplay);
				
				btnDisplay.addActionListener(this);
			}
		
		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==btnDisplay)
					{
						String s1=txtName.getText();
						txtNameDisplay.setText(s1);
						txtName.setText("");
					}
			}
	}