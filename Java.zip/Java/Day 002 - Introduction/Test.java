class Test
{
	public static void main(Strings args[])
		{
			System.out.println("Welcome to java!");

		}

}