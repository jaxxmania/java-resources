public class EgSwitch
{
public static void main(String args[])
{
int a=10;
int b=20;
int choice=4;

System.out.println("1.Add\n2.Sub\n3.Mul");

switch (choice)

{
case 1:
	System.out.println((a+b));
	break;
case 2:
	System.out.println((a-b));
	break;
case 3:
	System.out.println((a*b));
	break;
default:
	System.out.println("\"Error\"");
}
}
}