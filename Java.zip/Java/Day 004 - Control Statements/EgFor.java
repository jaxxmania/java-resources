public class EgFor
{
 public static void main(String args[])
{
  int num=5,sum=0;

for(;num>=1;num--)
	sum+=num;

System.out.println("sum="+sum);
}
}