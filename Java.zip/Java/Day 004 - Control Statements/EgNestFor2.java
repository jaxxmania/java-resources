public class EgNestFor2
{
public static void main(String args[])
{

for (int i=5;i>=1;i--)
{
int j;
for (j=1;j<=i;j++)
{
System.out.print("* ");
}

System.out.println();

for(int k=0;k<=j;k++)
System.out.print("  ");

}

}

}