import java.awt.*;
import java.applet.*;

/*
	<applet code="EgAWT.class" width="400" height="400">
	</applet>
*/

public class EgAWT extends Applet
	{
		Label lblName,lblAdd,lblHobby,lblCountry,lblComment;
		TextField txtName,txtAdd;
		Button btnOk,btnClear;
		Checkbox c1,c2,c3;
		Choice country;
		TextArea t1;
		
		public void init()
			{
				setLayout(null);
				
				lblName=new Label("Name : ");
				lblAdd=new Label("Address : ");
				lblHobby=new Label("Hobby : ");
				lblCountry=new Label("Country : ");
				lblComment=new Label("Comment : ");
				
				txtName=new TextField(20);
				txtAdd=new TextField(50);
				
				btnOk=new Button("OK");
				btnClear=new Button("Clear");
				
				c1=new Checkbox("Music");
				c2=new Checkbox("Dance");
				c3=new Checkbox("Sports");
				
				country=new Choice();
				
				country.add("Nepal");
				country.add("USA");
				country.add("UK");
				
				t1=new TextArea(" ",50,50);
				
				add(lblName);
				lblName.setBounds(20,30,120,25);
				
				add(txtName);
				txtName.setBounds(140,30,120,25);
				
				add(lblAdd);
				lblAdd.setBounds(20,60,120,25);
				
				add(txtAdd);
				txtAdd.setBounds(140,60,120,25);
				
				add(btnOk);
				btnOk.setBounds(50,100,50,25);
				
				add(btnClear);
				btnClear.setBounds(150,100,50,25);
				
				add(lblHobby);
				lblHobby.setBounds(20,125,50,25);
				
				add(c1);
				c1.setBounds(20,160,60,25);
				
				add(c2);
				c2.setBounds(90,160,60,25);
				
				add(c3);
				c3.setBounds(150,160,60,25);
				
				add(lblCountry);
				lblCountry.setBounds(20,190,50,25);
				
				add(country);
				country.setBounds(80,190,80,25);
				
				add(lblComment);
				lblComment.setBounds(20,215,80,25);
				
				add(t1);
				t1.setBounds(110,215,200,200);
			}
	}