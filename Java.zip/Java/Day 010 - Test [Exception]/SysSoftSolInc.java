import java.io.*;

class Employee
	{
		public String name;
		public int age,id;
		
		public void display()
			{
				System.out.pritnln("\nID = "+id);
				System.out.pritnln("Name = "+name);
				System.out.pritnln("Age = "+age);
			}
		
	}

public class SysSoftSolInc
	{
		public static void main (String args[]) throws Exception
			{
				int i,flag=0;
				Employee emp[];
				
				for(i=0;i<3;i++)
					emp[i]=new Employee();
				
				BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
				
				try
				{
					for(int i=0;i<=3;i++)
								{
									emp[i].id=Integer.parseInt(bfr.readLine());
									emp[i].name=bfr.readLine();
									emp[i].age=Integer.parseInt(bfr.readLine());
								}
					
					for(int i=0;i<3;i++)
								{
									System.out.println("\nID="+emp[i].id);
									System.out.println("Name="+emp[i].name);
									System.out.println("Age="+emp[i].age);
									
									if(name[i]==name[i+1])
										flag=1;
								}
										
					if(flag==1)
						System.out.println("\nDuplicate Detected !!!");
				}
				
				catch(ArrayIndexOutOfBoundsException e)
					{
						System.out.println("\nError : "+e);
					}
			}
	}